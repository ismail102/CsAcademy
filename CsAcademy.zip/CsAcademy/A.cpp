#include<bits/stdc++.h>
using namespace std;
int main()
{
    int m,b,y;
    int ara[10];
    while(cin>>ara[0]>>ara[1]>>ara[2])
    {

        int t;

        if(b<=m and y>=m){
            t = abs(m-y)+abs(m-b);
        }
        else if(m<=b and y>=b){
            t = abs(y-b)+abs(b-m);
        }
        else if(b<=m and y<=b){
            t = abs(y-b)+abs(b-m);
        }
        else if(m<=b and y<=m){
            t = abs(y-m)+abs(b-m);
        }
        else if((y>=m and y<=b) or (y>=b and y<=m)){
            t = abs(y-m) + abs(m-b);
        }
        cout<<t<<endl;

    }

    return 0;

}