#include<bits/stdc++.h>
#define Max 100005
using namespace std;
int ara[Max];
int main()
{
    int d,t,v1,v2;
    while(cin>>d>>t>>v1>>v2)
    {
        int netv = (v1-v2);
        int dis = netv*t;
        int ans;
        if(dis>=d){
            ans = d/abs(netv);
            if(d%abs(netv)!=0) ans++;
            cout<<ans<<endl;
            continue;
        }

        dis = d - dis;

        ans = dis/v1;
        if(dis%v1!=0) ans+=1;
        cout<<ans+t<<endl;
    }
    return 0;
}
