    ///    Author: Ismail Hossain(Mukul)
    ///    Univarsity: Chittagong University of Engineering Annd Technology(Bangladesh)
    ///    Uva:ISMAIL_HOSSAIN
    ///    Codeforces: ISMAIL_HOSSAIN
    ///    SPOJ:ismail_102
    ///    HackerRank: ismail_102
    ///    csacademy: ISMAIL_HOSSAIN
    ///    Facebook: Smily Mukul

    //BISMILLAHIR RAHMANIR RAHIM
    #include<bits/stdc++.h>
    #define sf              scanf
    #define pf              print
    #define dd              double
    #define fr              first
    #define sc              second
    #define pb              push_back
    #define MP              make_pair
    #define ll              long long
    #define PI              acos(-1.0)
    #define vci             vector<ll>
    #define pll             pair<ll, ll>
    #define vcc             vector<char>
    #define sz(a)           (a.size())
    #define pii             pair<int, int>
    #define vcs             vector<string>
    #define read(a)         scanf("%d",&a)
    #define readI1(a)       scanf("%I64d",&a)
    #define read2(a,b)      scanf("%d%d",&a,&b)
    #define FOR(i, s, e)    for(ll i=s; i<e; i++)
    #define read3(a,b,c)    scanf("%d%d%d",&a,&b,&c)
    #define readI2(a,b)     scanf("%I64d %I64d",&a,&b)
    #define mem(a, b)       memset(ara, value, sizeof(ara))
    #define readI3(a,b,C)   scanf("%I64d %I64d %I64d",&a,&b,&c)
    #define open()          freopen("input.txt", "r", stdin)
    #define show()          freopen("output.txt", "w", stdout)
    #define one(a)          __biltin_popcount(a)
    #define Max 2000+5
    #define inf INFINITY
    using namespace std;
    int dx[]={+1,-1,0,0};
    int dy[]={0,0,+1,-1};
    int Set(int n,int pos){ return n = (n | (1<<pos));}
    bool check(int n,int pos){return (bool)(n & (1<<pos));}
    int clearr(int n,int pos){return n = (n & ~(1<<pos));}
    int update(int n,int pos){return n = (n ^ (1<<pos));}

    vector<int>vc;
     int n,m;

     int vis[505][505];
     char grid[505][505];
     int ans[505][505];

    void dfs(int x,int y)
    {
        ans[x][y]=1;

       // if(x+1>=n or x-1<0 or y+1>=m or y-1<0) return;

       //cout<<x<<' '<<y<<' '<<grid[x][y]<<endl;

        if(grid[x][y+1]=='L' and y+1<m){
            dfs(x,y+1);
        }
        if(grid[x][y-1]=='R' and y-1>=0){
            dfs(x,y-1);
        }
        if(grid[x+1][y]=='U' and x+1<n){
            dfs(x+1,y);
        }
        if(grid[x-1][y]=='D' and x-1>=0){
            dfs(x-1,y);
        }

    }


    int main()
    {
        int t,sum;

        while(cin>>n>>m)
        {

            for(int i=0;i<n;i++){
                for(int j=0;j<m;j++){
                        cin>>grid[i][j];
                        ans[i][j]=0;
                }
            }

            for(int i=0;i<m;i++){
                if(grid[0][i]=='U'){
                    dfs(0,i);
                }
            }

            for(int i=0;i<n;i++){
                if(grid[i][m-1]=='R'){
                    dfs(i,m-1);
                }
            }
            for(int i=0;i<m;i++){
                if(grid[n-1][i]=='D'){
                    dfs(n-1,i);
                }
            }
            for(int i=0;i<n;i++){
                //cout<<grid[i][0]<<endl;
                if(grid[i][0]=='L'){
                    dfs(i,0);
                }
            }

            int rslt=0;


            for(int i=0;i<n;i++){
                for(int j=0;j<m;j++){
                   // cout<<ans[i][j]<<' ';
                   rslt+=ans[i][j];
                }
                //cout<<endl;
            }


            cout<<rslt<<endl;



        }
        return 0;
    }
