#include<bits/stdc++.h>
using namespace std;
#define pii pair<int,int>

double sq(int a)
{
    return a*a;
}
int main()
{
    int n,m;
    int x,y;
    cin>>n>>m;
    pii dog[3000],cat[3000];
    for(int i=0;i<n;i++){
        cin>>x>>y;
        cat[i].first =  x;
        cat[i].second = y;
    }
    for(int i=0;i<m;i++){
        cin>>x>>y;
        dog[i].first = x;
        dog[i].second = y;
    }

    int ans[3000];

    memset(ans,0,sizeof(ans));

    for(int i=0;i<m;i++){
        double mn = 1000000007.0;
        int idx=10000;
        for(int j=0;j<n;j++){
            double dis =  (double)(sqrt(sq(dog[i].first - cat[j].first) + sq(dog[i].second - cat[j].second) ));
            
            //cout<<i<<'='<<dis<<' '<<mn<<' ';
            if(dis<mn){
                mn = dis;
                idx = j;
            }
            else if(dis==mn){
                if(j<idx) idx = j; 
            }

        }
        //cout<<endl;
        //cout<<idx<<endl;
        ans[idx]++;


    }
    int cnt=0;
    for(int i=0;i<n;i++){
        if(ans[i]==1) cnt++;
    }
    cout<<cnt<<endl;


    return 0;
}