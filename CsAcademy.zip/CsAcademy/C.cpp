#include<bits/stdc++.h>
using namespace std;
int ara[100005];
int main()
{

    int n,k;
    while(cin>>n>>k)
    {
        memset(ara,0,sizeof(ara));

        if(k==0){
            for(int i=1;i<=n;i++){
                if(i!=n) cout<<i<<' ';
                else cout<<i<<endl;
            }
            continue;
        }
        int t = (n-1)*n/2;
        
        if(k==t)
        {
            for(int i=n;i>=1;i--){
                if(i!=1) cout<<i<<' ';
                else cout<<i<<endl;
            }
            continue;

        }

        t  = t - k;
       // cout<<t<<' ';
        int d = t/(n-1);
       // cout<<d<<' ';
        int N = n - d;
        //cout<<N<<' ';
        int idx = N - t%(n-1);

       // cout<<N - (t%(n-1))<<' ';

        ara[idx] = d + 1;
        cout<<d+1<<endl;

        for(int i=1;i<=d;i++){
            ara[i-1] = i; 
        }

        for(int i = 1,j=n;i<=n;i++){
            if(ara[i-1]==0){
                ara[i-1] = j;
                j--;
            }
        }

        for(int i=0;i<n;i++){
            if(i!=n-1) cout<<ara[i]<<' ';
            else cout<<ara[i]<<endl;
        }
    }
    return 0;
}